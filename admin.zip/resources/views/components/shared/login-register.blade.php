<div class="modal fade log-reg" id="loginModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-sm" style="max-width: 500px;">
        <div class="modal-content">
             <div class="modal-body">
                <x-auth.login/>
            </div>
        </div>
    </div>
  </div>
