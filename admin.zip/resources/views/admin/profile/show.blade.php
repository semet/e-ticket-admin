<x-layouts.admin>
    <div class="row">
        <div class="col-md-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <x-admin.profile.account/>
                    <hr>
                    <x-admin.profile.password/>
                </div>
            </div>
        </div>
    </div>
</x-layouts.admin>
