<?php

return [
    'couple_price' => 500000,
    'couple_actual_price' => 450000,

    'family_price' => 800000,
    'family_actual_price' => 750000
];
