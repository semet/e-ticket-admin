<?php if (isset($component)) { $__componentOriginal2b4fb1c6c26cbcbc26d950a3971ca92bb1fca250 = $component; } ?>
<?php $component = App\View\Components\Layouts\Admin::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Layouts\Admin::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="row">
        <div class="col-12 col-xl-12 stretch-card">
            <div class="row flex-grow-1">
                
                <?php if (isset($component)) { $__componentOriginalb9dc589d0036dd038a5528417eec2be08e46db4b = $component; } ?>
<?php $component = App\View\Components\Admin\Home\UserCount::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.home.user-count'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Admin\Home\UserCount::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb9dc589d0036dd038a5528417eec2be08e46db4b)): ?>
<?php $component = $__componentOriginalb9dc589d0036dd038a5528417eec2be08e46db4b; ?>
<?php unset($__componentOriginalb9dc589d0036dd038a5528417eec2be08e46db4b); ?>
<?php endif; ?>
                
                <?php if (isset($component)) { $__componentOriginal400091d19386f45de46e85cbba34296637713e21 = $component; } ?>
<?php $component = App\View\Components\Admin\Home\IncomeCount::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.home.income-count'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Admin\Home\IncomeCount::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal400091d19386f45de46e85cbba34296637713e21)): ?>
<?php $component = $__componentOriginal400091d19386f45de46e85cbba34296637713e21; ?>
<?php unset($__componentOriginal400091d19386f45de46e85cbba34296637713e21); ?>
<?php endif; ?>
                
                <?php if (isset($component)) { $__componentOriginal102159499bf892407782937ed024a60389eba870 = $component; } ?>
<?php $component = App\View\Components\Admin\Home\BookingCount::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.home.booking-count'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Admin\Home\BookingCount::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal102159499bf892407782937ed024a60389eba870)): ?>
<?php $component = $__componentOriginal102159499bf892407782937ed024a60389eba870; ?>
<?php unset($__componentOriginal102159499bf892407782937ed024a60389eba870); ?>
<?php endif; ?>
            </div>
        </div>
        
        <?php if (isset($component)) { $__componentOriginale4cb73f3179fb6ff376a23b96ad637d1f7910884 = $component; } ?>
<?php $component = App\View\Components\Admin\Home\TodayFlight::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.home.today-flight'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Admin\Home\TodayFlight::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale4cb73f3179fb6ff376a23b96ad637d1f7910884)): ?>
<?php $component = $__componentOriginale4cb73f3179fb6ff376a23b96ad637d1f7910884; ?>
<?php unset($__componentOriginale4cb73f3179fb6ff376a23b96ad637d1f7910884); ?>
<?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2b4fb1c6c26cbcbc26d950a3971ca92bb1fca250)): ?>
<?php $component = $__componentOriginal2b4fb1c6c26cbcbc26d950a3971ca92bb1fca250; ?>
<?php unset($__componentOriginal2b4fb1c6c26cbcbc26d950a3971ca92bb1fca250); ?>
<?php endif; ?>
<?php /**PATH /home/hamdani/code/e-ticket-admin/resources/views/admin/home.blade.php ENDPATH**/ ?>