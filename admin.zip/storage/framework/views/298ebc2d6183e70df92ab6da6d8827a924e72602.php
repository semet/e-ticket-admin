<?php if (isset($component)) { $__componentOriginal7c82e5f349ef25bc970c1f6243ded321b5bb0b6f = $component; } ?>
<?php $component = App\View\Components\Layouts\Main::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.main'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Layouts\Main::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
       Profil User
     <?php $__env->endSlot(); ?>
    <section class="trending pt-6 pb-0 bg-lgrey">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div class="single-content">
                        <div id="highlight" class="mb-4">
                            <div class="single-full-title border-b mb-2 pb-2">
                                <div class="single-title">
                                    <h4 class="mb-1">Detail Order</h4>
                                </div>
                            </div>
                            <div class="card card-body">
                                <dl class="row">
                                    <dt class="col-sm-3 my-2">Order ID</dt>
                                    <dd class="col-sm-9 my-2"><?php echo e($order->number); ?></dd>

                                    <dt class="col-sm-3 my-2">Tanggal</dt>
                                    <dd class="col-sm-9 my-2"><?php echo e($order->date); ?></dd>

                                    <dt class="col-sm-3 my-2">Jam Terbang</dt>
                                    <dd class="col-sm-9 my-2"><?php echo e(substr($order->schedule->start_hour, 0, 5). ' - ' .substr($order->schedule->end_hour, 0, 5)); ?></dd>

                                    <dt class="col-sm-3 my-2">Status</dt>
                                    <dd class="col-sm-9 my-2">
                                        <span class="badge <?php if($order->status == 'pending'): ?> bg-info <?php elseif($order->status == 'confirmed'): ?> bg-success <?php elseif($order->status == 'cancelled'): ?> bg-danger <?php endif; ?>"><?php echo e($order->status); ?></span>
                                    </dd>

                                    
                                </dl>
                                <h4>Detail Penumpang</h4>
                                <table class="table table-responsive">
                                    <thead>
                                        <tr>
                                            <th scope="col">ID</th>
                                            <th scope="col">Nama Lengkap</th>
                                            <th scope="col">Email</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $order->passengers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $passenger): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th scope="row"><?php echo e($passenger->nik); ?></th>
                                            <td><?php echo e($passenger->name); ?></td>
                                            <td><?php echo e($passenger->email); ?></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- sidebar starts -->
                <?php if (isset($component)) { $__componentOriginal6e0ad727b791879571aefb74df8c2828931f2d48 = $component; } ?>
<?php $component = App\View\Components\User\Sidebar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('user.sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\User\Sidebar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6e0ad727b791879571aefb74df8c2828931f2d48)): ?>
<?php $component = $__componentOriginal6e0ad727b791879571aefb74df8c2828931f2d48; ?>
<?php unset($__componentOriginal6e0ad727b791879571aefb74df8c2828931f2d48); ?>
<?php endif; ?>
            </div>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7c82e5f349ef25bc970c1f6243ded321b5bb0b6f)): ?>
<?php $component = $__componentOriginal7c82e5f349ef25bc970c1f6243ded321b5bb0b6f; ?>
<?php unset($__componentOriginal7c82e5f349ef25bc970c1f6243ded321b5bb0b6f); ?>
<?php endif; ?>
<?php /**PATH /home/hamdani/code/e-ticket/resources/views/user/order-details.blade.php ENDPATH**/ ?>