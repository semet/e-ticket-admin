<?php if (isset($component)) { $__componentOriginal2b4fb1c6c26cbcbc26d950a3971ca92bb1fca250 = $component; } ?>
<?php $component = App\View\Components\Layouts\Admin::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Layouts\Admin::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="row">
        <div class="col-md-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <?php if (isset($component)) { $__componentOriginala4d7da7e938fbf069bf8e3bbb1ae61703813400e = $component; } ?>
<?php $component = App\View\Components\Admin\Profile\Account::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.profile.account'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Admin\Profile\Account::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala4d7da7e938fbf069bf8e3bbb1ae61703813400e)): ?>
<?php $component = $__componentOriginala4d7da7e938fbf069bf8e3bbb1ae61703813400e; ?>
<?php unset($__componentOriginala4d7da7e938fbf069bf8e3bbb1ae61703813400e); ?>
<?php endif; ?>
                    <hr>
                    <?php if (isset($component)) { $__componentOriginal130c9cbd3eb5db7fbd6dfb3a274c2df1b20a3376 = $component; } ?>
<?php $component = App\View\Components\Admin\Profile\Password::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.profile.password'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Admin\Profile\Password::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal130c9cbd3eb5db7fbd6dfb3a274c2df1b20a3376)): ?>
<?php $component = $__componentOriginal130c9cbd3eb5db7fbd6dfb3a274c2df1b20a3376; ?>
<?php unset($__componentOriginal130c9cbd3eb5db7fbd6dfb3a274c2df1b20a3376); ?>
<?php endif; ?>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2b4fb1c6c26cbcbc26d950a3971ca92bb1fca250)): ?>
<?php $component = $__componentOriginal2b4fb1c6c26cbcbc26d950a3971ca92bb1fca250; ?>
<?php unset($__componentOriginal2b4fb1c6c26cbcbc26d950a3971ca92bb1fca250); ?>
<?php endif; ?>
<?php /**PATH /home/hamdani/code/e-ticket-admin/resources/views/admin/profile/show.blade.php ENDPATH**/ ?>