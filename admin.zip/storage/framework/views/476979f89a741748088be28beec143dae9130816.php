<?php if (isset($component)) { $__componentOriginal7c82e5f349ef25bc970c1f6243ded321b5bb0b6f = $component; } ?>
<?php $component = App\View\Components\Layouts\Main::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.main'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Layouts\Main::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        Pending Order
     <?php $__env->endSlot(); ?>
    <section class="trending pt-6 pb-0 bg-lgrey">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-xs-12 mb-4 mx-auto">
                    <div class="payment-book">
                        <div class="booking-box">
                            <div class="card card-body">
                                <h4>Order anda sedang menunggu pembayaran</h4>
                                <p>Silakan periksa E-mail anda untuk detail petunjuk pembayaran</p> <br/>
                                <p>Terimakasih.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7c82e5f349ef25bc970c1f6243ded321b5bb0b6f)): ?>
<?php $component = $__componentOriginal7c82e5f349ef25bc970c1f6243ded321b5bb0b6f; ?>
<?php unset($__componentOriginal7c82e5f349ef25bc970c1f6243ded321b5bb0b6f); ?>
<?php endif; ?>
<?php /**PATH /home/hamdani/code/e-ticket/resources/views/checkout-pending.blade.php ENDPATH**/ ?>