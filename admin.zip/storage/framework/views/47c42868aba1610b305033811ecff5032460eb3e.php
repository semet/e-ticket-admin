<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="zxx">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name'). ': E-Ticket'); ?></title>
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('assets/images/favicon.ico')); ?>">
    <!-- Bootstrap core CSS -->
    <link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
    <!--Custom CSS-->
    <link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet" type="text/css">
    <!--Plugin CSS-->
    <link href="<?php echo e(asset('assets/css/plugin.css')); ?>" rel="stylesheet" type="text/css">

    <!--Font Awesome-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-toast-plugin/1.3.2/jquery.toast.css" integrity="sha512-8D+M+7Y6jVsEa7RD6Kv/Z7EImSpNpQllgaEIQAtqHcI0H6F4iZknRj0Nx1DCdB+TwBaS+702BGWYC0Ze2hpExQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/js/bootstrap-datepicker/css/bootstrap-datepicker.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/js/sweetalert2/sweetalert2.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/fonts/line-icons.css')); ?>" type="text/css">
</head>

    <!-- Preloader -->
    <div id="preloader">
        <div id="status"></div>
    </div>
    <!-- Preloader Ends -->

    <!-- header starts -->
    <?php if (isset($component)) { $__componentOriginalfed4e9cf4774aac0846857c7fe44dbed8d282dae = $component; } ?>
<?php $component = App\View\Components\Partials\Header::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('partials.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Partials\Header::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfed4e9cf4774aac0846857c7fe44dbed8d282dae)): ?>
<?php $component = $__componentOriginalfed4e9cf4774aac0846857c7fe44dbed8d282dae; ?>
<?php unset($__componentOriginalfed4e9cf4774aac0846857c7fe44dbed8d282dae); ?>
<?php endif; ?>
    <!-- header ends -->

    <!-- BreadCrumb Starts -->
    <?php if (isset($component)) { $__componentOriginalf7b8929458f9de5fc736b9d94ce2580e9bb8628b = $component; } ?>
<?php $component = App\View\Components\Partials\PageTitle::resolve(['title' => $title] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('partials.page-title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Partials\PageTitle::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf7b8929458f9de5fc736b9d94ce2580e9bb8628b)): ?>
<?php $component = $__componentOriginalf7b8929458f9de5fc736b9d94ce2580e9bb8628b; ?>
<?php unset($__componentOriginalf7b8929458f9de5fc736b9d94ce2580e9bb8628b); ?>
<?php endif; ?>
    <!-- BreadCrumb Ends -->

   <?php echo e($slot); ?>




    <!-- footer starts -->
    <?php if (isset($component)) { $__componentOriginalcf4e2a59bda9c630ae6e0ad5cda8d9ec6b047d4a = $component; } ?>
<?php $component = App\View\Components\Partials\Footer::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('partials.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Partials\Footer::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcf4e2a59bda9c630ae6e0ad5cda8d9ec6b047d4a)): ?>
<?php $component = $__componentOriginalcf4e2a59bda9c630ae6e0ad5cda8d9ec6b047d4a; ?>
<?php unset($__componentOriginalcf4e2a59bda9c630ae6e0ad5cda8d9ec6b047d4a); ?>
<?php endif; ?>
    <!-- footer ends -->

    <!-- Back to top start -->
    <div id="back-to-top">
        <a href="#"></a>
    </div>
    <!-- Back to top ends -->

    <!-- search popup -->
    <div id="search1">
        <button type="button" class="close">×</button>
        <form>
            <input type="search" value="" placeholder="type keyword(s) here" />
            <button type="submit" class="btn btn-primary">Search</button>
        </form>
    </div>

    <!-- login registration modal -->
   <?php if (isset($component)) { $__componentOriginala490583f7f2368c4427c50820963b892a2de6ef7 = $component; } ?>
<?php $component = App\View\Components\Shared\LoginRegister::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('shared.login-register'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Shared\LoginRegister::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala490583f7f2368c4427c50820963b892a2de6ef7)): ?>
<?php $component = $__componentOriginala490583f7f2368c4427c50820963b892a2de6ef7; ?>
<?php unset($__componentOriginala490583f7f2368c4427c50820963b892a2de6ef7); ?>
<?php endif; ?>
    <!-- *Scripts* -->
    <script src="<?php echo e(asset('assets/js/jquery-3.5.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/particles.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/particlerun.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/plugin.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/axios/axios.min.js')); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-toast-plugin/1.3.2/jquery.toast.min.js" integrity="sha512-zlWWyZq71UMApAjih4WkaRpikgY9Bz1oXIW5G0fED4vk14JjGlQ1UmkGM392jEULP8jbNMiwLWdM8Z87Hu88Fw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap-datepicker/js/bootstrap-datepicker.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/sweetalert2/sweetalert2.all.min.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
    <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/custom-accordian.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/custom-nav.js')); ?>"></script>

</body>
</html>
<?php /**PATH /home/hamdani/code/e-ticket-admin/resources/views/components/layouts/main.blade.php ENDPATH**/ ?>