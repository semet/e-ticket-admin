<?php if (isset($component)) { $__componentOriginal7c82e5f349ef25bc970c1f6243ded321b5bb0b6f = $component; } ?>
<?php $component = App\View\Components\Layouts\Main::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.main'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Layouts\Main::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        Registerasi
     <?php $__env->endSlot(); ?>
    <section class="login-register pt-6 pb-6">
        <div class="container">
            <div class="log-main blog-full log-reg w-75 mx-auto">
                <div class="row">
                    <div class="col-lg-6 mx-auto">
                        <h3 class="text-center border-b pb-2">Login</h3>
                        <?php if(session()->has('emailReminder')): ?>
                        <div class="alert alert-warning p-4" role="alert">
                            <?php echo e(session()->get('emailReminder')); ?> <br/>
                            Atau jika anda tidak menerima Email verifikasi <br/>
                            <a href="<?php echo e(route('register.resend.verification')); ?>">kirim</a> ulang sekarang
                        </div>
                        <?php endif; ?>
                        <?php if(session()->has('success')): ?>
                        <div class="alert alert-success p-4" role="alert">
                            <?php echo e(session()->get('success')); ?>

                        </div>
                        <?php endif; ?>
                        <form method="post" action="<?php echo e(route('register.post')); ?>" id="registerForm">
                            <?php echo csrf_field(); ?>
                            <div class="form-group mb-2">
                                <input type="email" name="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email" placeholder="email@example.com">
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group mb-2">
                                <input type="password" name="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="password" placeholder="Password">
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="comment-btn mb-2 pb-2 text-center border-b">
                                <button class="nir-btn" type="submit">Registetr</button>
                            </div>
                            <p class="text-center">belum ada akun? <a href="#" data-bs-toggle="modal" data-bs-target="#loginModal" class="theme">Login</a></p>
                        </form>
                        <hr class="log-reg-hr position-relative my-4 overflow-visible">
                        <div class="log-reg-button d-sm-flex align-items-center justify-content-between">
                            <a href="<?php echo e(route('login.facebook.redirect')); ?>" class="btn btn-fb w-50 me-1">
                                <i class="fab fa-facebook"></i> Login with Facebook
                            </a>
                            <a href="<?php echo e(route('login.google.redirect')); ?>" class="btn btn-google w-50 ms-1">
                                <i class="fab fa-google"></i> Login with Google
                            </a>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7c82e5f349ef25bc970c1f6243ded321b5bb0b6f)): ?>
<?php $component = $__componentOriginal7c82e5f349ef25bc970c1f6243ded321b5bb0b6f; ?>
<?php unset($__componentOriginal7c82e5f349ef25bc970c1f6243ded321b5bb0b6f); ?>
<?php endif; ?>
<?php /**PATH /home/hamdani/code/e-ticket/resources/views/auth/login.blade.php ENDPATH**/ ?>