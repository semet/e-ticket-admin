<div class="col-12 col-xl-12">
    <div class="card">
        <div class="card-header">
            <h3>Penerbangan Hari ini</h3>
        </div>
        <div class="card-body">
            <table class="table table-responsive">
                <thead>
                    <tr>
                        <th scope="col">Take off</th>
                        <th scope="col">Landing</th>
                        <th scope="col">Lokasi</th>
                        <th scope="col">Total Penumpang</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e(substr($sch->start_hour, 0, 5)); ?></th>
                        <td><?php echo e(substr($sch->end_hour, 0, 5)); ?></td>
                        <td><?php echo e($sch->destination->name); ?></td>
                        <td><?php echo e(count($sch->bookings)); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php /**PATH /home/hamdani/code/e-ticket-admin/resources/views/components/admin/home/today-flight.blade.php ENDPATH**/ ?>