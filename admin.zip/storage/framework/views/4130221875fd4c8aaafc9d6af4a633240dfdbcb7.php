<?php if (isset($component)) { $__componentOriginal2b4fb1c6c26cbcbc26d950a3971ca92bb1fca250 = $component; } ?>
<?php $component = App\View\Components\Layouts\Admin::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Layouts\Admin::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="row">
        <div class="col-md-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <table class="table table-bordered table-hover datatable">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>NIK/Passport</th>
                                <th>Nama Lengkap</th>
                                <th>Email</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->startPush('scripts'); ?>
    <script type="text/javascript">
        $(function () {
            var table = $('.datatable').DataTable({
                processing: true,
                serverSide: true,
                ajax: '<?php echo e(route('admin.passengers.list')); ?>',
                columns: [
                    {data: 'DT_RowIndex', name: 'DT_RowIndex'},
                    {data: 'nik', name: 'nik'},
                    {data: 'name', name: 'name'},
                    {data: 'email', name: 'email'},
                ]
            });
        });
      </script>
    <?php $__env->stopPush(); ?>
      <?php if (isset($component)) { $__componentOriginal0be8990d8653d19af0b3ac36178d74f2b6ec11fb = $component; } ?>
<?php $component = App\View\Components\Admin\Booking\Show::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.booking.show'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Admin\Booking\Show::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0be8990d8653d19af0b3ac36178d74f2b6ec11fb)): ?>
<?php $component = $__componentOriginal0be8990d8653d19af0b3ac36178d74f2b6ec11fb; ?>
<?php unset($__componentOriginal0be8990d8653d19af0b3ac36178d74f2b6ec11fb); ?>
<?php endif; ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2b4fb1c6c26cbcbc26d950a3971ca92bb1fca250)): ?>
<?php $component = $__componentOriginal2b4fb1c6c26cbcbc26d950a3971ca92bb1fca250; ?>
<?php unset($__componentOriginal2b4fb1c6c26cbcbc26d950a3971ca92bb1fca250); ?>
<?php endif; ?>
<?php /**PATH /home/hamdani/code/e-ticket-admin/resources/views/admin/passenger/index.blade.php ENDPATH**/ ?>