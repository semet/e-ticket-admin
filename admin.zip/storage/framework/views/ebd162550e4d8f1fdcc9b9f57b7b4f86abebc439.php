<?php if (isset($component)) { $__componentOriginal7c82e5f349ef25bc970c1f6243ded321b5bb0b6f = $component; } ?>
<?php $component = App\View\Components\Layouts\Main::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.main'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Layouts\Main::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        Destination Details
     <?php $__env->endSlot(); ?>
    <!-- top Destination starts -->
    <section class="trending pt-6 pb-0 bg-lgrey">
       <div class="container">
           <div class="row">
               <div class="col-lg-8">
                   <div class="single-content">
                       <div id="highlight" class="mb-4">
                           <div class="single-full-title border-b mb-2 pb-2">
                               <div class="single-title">
                                   <h2 class="mb-1"><?php echo e($destination->name); ?></h2>
                                   <div class="rating-main d-flex align-items-center">
                                       <p class="mb-0 me-2"><i class="icon-location-pin"></i> <?php echo e($destination->location); ?></p>
                                       <div class="rating me-2">
                                           <span class="fa fa-star checked"></span>
                                           <span class="fa fa-star checked"></span>
                                           <span class="fa fa-star checked"></span>
                                           <span class="fa fa-star checked"></span>
                                           <span class="fa fa-star checked"></span>
                                       </div>
                                   </div>
                               </div>
                           </div>

                           <div class="description-images mb-4">
                               <img src="<?php echo e(asset('assets/images/trending/trending-large.jpg')); ?>" alt="" class="w-100 rounded">
                           </div>

                           <div class="description mb-2">
                               <h4>Description</h4>
                                <p><?php echo e($destination->description); ?></p>
                            </div>


                       </div>

                       <div  id="single-map" class="single-map mb-4">
                           <h4>Map</h4>
                           <div class="map rounded overflow-hidden">
                               <div style="width: 100%">
                                   
                               </div>
                           </div>
                       </div>

                       <!-- blog review -->
                       <div  id="single-add-review" class="single-add-review">
                           <h4>Write a Review</h4>
                           <form>
                               <div class="row">
                                   <div class="col-md-6">
                                       <div class="form-group mb-2">
                                           <input type="text" placeholder="Name">
                                       </div>
                                   </div>
                                   <div class="col-md-6">
                                       <div class="form-group mb-2">
                                           <input type="email" placeholder="Email">
                                       </div>
                                   </div>
                                   <div class="col-md-12">
                                       <div class="form-group mb-2">
                                           <textarea>Comment</textarea>
                                       </div>
                                   </div>
                                   <div class="col-md-6">
                                       <div class="form-btn">
                                           <a href="#" class="nir-btn">Submit Review</a>
                                       </div>
                                   </div>
                               </div>
                           </form>
                       </div>
                   </div>
               </div>

               <!-- sidebar starts -->
               <?php if (isset($component)) { $__componentOriginal70102adda21b1d1384763957a064c2aeee2701ec = $component; } ?>
<?php $component = App\View\Components\Shared\Sidebar::resolve(['destination' => $destination] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('shared.sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Shared\Sidebar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal70102adda21b1d1384763957a064c2aeee2701ec)): ?>
<?php $component = $__componentOriginal70102adda21b1d1384763957a064c2aeee2701ec; ?>
<?php unset($__componentOriginal70102adda21b1d1384763957a064c2aeee2701ec); ?>
<?php endif; ?>
           </div>
       </div>
   </section>
   <!-- top Destination ends -->
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7c82e5f349ef25bc970c1f6243ded321b5bb0b6f)): ?>
<?php $component = $__componentOriginal7c82e5f349ef25bc970c1f6243ded321b5bb0b6f; ?>
<?php unset($__componentOriginal7c82e5f349ef25bc970c1f6243ded321b5bb0b6f); ?>
<?php endif; ?>
<?php /**PATH /home/hamdani/code/e-ticket/resources/views/destination.blade.php ENDPATH**/ ?>