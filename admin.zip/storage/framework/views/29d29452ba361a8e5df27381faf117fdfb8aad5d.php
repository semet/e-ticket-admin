<?php if (isset($component)) { $__componentOriginal2b4fb1c6c26cbcbc26d950a3971ca92bb1fca250 = $component; } ?>
<?php $component = App\View\Components\Layouts\Admin::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Layouts\Admin::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="search-box p-4 bg-white rounded mb-3 box-shadow">
        <form class="forms-sample" action="<?php echo e(url()->current()); ?>" method="get" id="filterForm">
            <div class="row align-items-center">
                <div class="col-lg-3">
                <h5>Jangka Waktu</h5>
                </div>
                <div class="col-lg-3 col-md-4">
                    <input type="text" class="form-control datePicker" name="start_date" id="start_date">
                </div>
                <div class="col-lg-3 col-md-4">
                    <input type="text" class="form-control datePicker" name="end_date" id="end_date">
                </div>
                <div class="col-lg-3 col-md-4">
                    <button class="btn btn-primary btn-sm" type="submit">
                        <i data-feather="filter"></i>
                    </button>
                </div>
            </div>
        </form>
    </div>
    <div class="row">
        <div class="col-md-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <table class="table table-bordered datatable">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Kode Booking</th>
                                <th>Nama Customer</th>
                                <th>Email</th>
                                <th>Status Pembayaran</th>
                                <th>Nominal</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->startPush('scripts'); ?>
    <script type="text/javascript">
        $(function () {

            var url = '<?php echo e(route('admin.bookings.list', ['startDate' => request()->get('start_date'), 'endDate' => request()->get('end_date')])); ?>';
            var parseResult = new DOMParser().parseFromString(url, "text/html");
            var parsedUrl = parseResult.documentElement.textContent;

            var table = $('.datatable').DataTable({
                processing: true,
                serverSide: true,
                ajax: parsedUrl,
                columns: [
                    {data: 'DT_RowIndex', name: 'DT_RowIndex'},
                    {data: 'number', name: 'number'},
                    {data: 'customer_name', name: 'customer_name'},
                    {data: 'customer_email', name: 'customer_email'},
                    {data: 'status', name: 'status'},
                    {data: 'nominal', name: 'nominal'},
                    {
                        data: 'action',
                        name: 'action',
                        orderable: true,
                        searchable: true
                    },
                ]
            });

            $('#showBooking').on('show.bs.modal', function (e) {
                const id = e.relatedTarget.id;
                const url = '<?php echo e(route('admin.bookings.show', ':param')); ?>'
                const parsedUrl = url.replace(':param', id)
                //
                axios.get(parsedUrl)
                .then(function (response) {
                   console.log(response.data)
                   $('#bookingCode').html(response.data.booking.number)
                   $('#bookingDate').html(response.data.booking.date)
                   $('#flightTime').html(`${response.data.booking.schedule.start_hour.substring(0, 5)} - ${response.data.booking.schedule.end_hour.substring(0, 5)}`)
                   $('#bookingStatus').html(response.data.booking.status)
                   $('#bookingType').html(response.data.booking.type)
                   $('#paymentTime').html(response.data.details.transaction_time)
                   $('#paymentStatus').html(response.data.details.transaction_status)
                   $('#paymentType').html(response.data.details.payment_type)
                })
            })
        });
      </script>
    <?php $__env->stopPush(); ?>
      <?php if (isset($component)) { $__componentOriginal0be8990d8653d19af0b3ac36178d74f2b6ec11fb = $component; } ?>
<?php $component = App\View\Components\Admin\Booking\Show::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.booking.show'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Admin\Booking\Show::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0be8990d8653d19af0b3ac36178d74f2b6ec11fb)): ?>
<?php $component = $__componentOriginal0be8990d8653d19af0b3ac36178d74f2b6ec11fb; ?>
<?php unset($__componentOriginal0be8990d8653d19af0b3ac36178d74f2b6ec11fb); ?>
<?php endif; ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2b4fb1c6c26cbcbc26d950a3971ca92bb1fca250)): ?>
<?php $component = $__componentOriginal2b4fb1c6c26cbcbc26d950a3971ca92bb1fca250; ?>
<?php unset($__componentOriginal2b4fb1c6c26cbcbc26d950a3971ca92bb1fca250); ?>
<?php endif; ?>
<?php /**PATH /home/hamdani/code/e-ticket-admin/resources/views/admin/booking/index.blade.php ENDPATH**/ ?>