<?php if (isset($component)) { $__componentOriginal7c82e5f349ef25bc970c1f6243ded321b5bb0b6f = $component; } ?>
<?php $component = App\View\Components\Layouts\Main::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.main'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Layouts\Main::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        Invoice
     <?php $__env->endSlot(); ?>
    <section class="trending pt-6 pb-0 bg-lgrey">
        <div class="container">
            <div class="row">
                <div class="col-lg-10 col-xs-12 mb-4 mx-auto">
                    <div class="payment-book">
                        <div class="booking-box">
                            <div class="travellers-info mb-4">
                                <h4>Detail Pesanan</h4>
                                <table>
                                    <thead>
                                        <th>No. Booking</th>
                                        <th>Tanggal</th>
                                        <th>Jam</th>
                                        <th>Jumlah Penumpang</th>
                                    </thead>
                                    <tbody>
                                    <tr>
                                        <td class="theme2"><?php echo e($booking->number); ?></td>
                                        <td class="theme2"><?php echo e(\Carbon\Carbon::parse($booking->date)->format('d/m/yy')); ?></td>
                                        <td class="theme2"><?php echo e(substr($booking->schedule->start_hour, 0, 5). ' - '. substr($booking->schedule->end_hour, 0, 5)); ?></td>
                                        <td class="theme2"><?php echo e($booking->passengers->count()); ?> orang</td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>

                            <div class="travellers-info mb-4">
                                <h4>Detail Penumpang</h4>
                                <table>
                                    <thead>
                                    <th>NIK</th>
                                    <th>Nama Lengkap</th>
                                    <th>Email</th>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $booking->passengers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $passenger): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="theme2"><?php echo e($passenger->nik); ?></td>
                                            <td class="theme2"><?php echo e($passenger->name); ?></td>
                                            <td class="theme2"><?php echo e($passenger->email); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="my-3">
                                <?php echo \SimpleSoftwareIO\QrCode\Facades\QrCode::generate(route('home.page')); ?>

                            </div>
                            <div class="d-flex gap-2 justify-content-center">
                                <button class="btn btn-primary">
                                    <i class="fas fa-print"></i>
                                </button>
                                <button class="btn btn-danger">
                                    <i class="fas fa-envelope"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7c82e5f349ef25bc970c1f6243ded321b5bb0b6f)): ?>
<?php $component = $__componentOriginal7c82e5f349ef25bc970c1f6243ded321b5bb0b6f; ?>
<?php unset($__componentOriginal7c82e5f349ef25bc970c1f6243ded321b5bb0b6f); ?>
<?php endif; ?>
<?php /**PATH /home/hamdani/code/e-ticket/resources/views/invoice.blade.php ENDPATH**/ ?>