<?php if (isset($component)) { $__componentOriginal2b4fb1c6c26cbcbc26d950a3971ca92bb1fca250 = $component; } ?>
<?php $component = App\View\Components\Layouts\Admin::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Layouts\Admin::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="row">
        <div class="col-md-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-end gap-2 my-2">
                        <a href="" class="btn btn-primary"><i class="link-icon" data-feather="plus"></i> Add Destinasi</a>
                    </div>
                    <table class="table table-bordered table-hover datatable">
                        <thead>
                            <tr>
                                <th scope="col">No</th>
                                <th scope="col">Nama Destinasi</th>
                                <th scope="col">Lokasi</th>
                                <th scope="col">Harga (Perorang)</th>
                                <th scope="col">Tipe Order</th>
                                <th scope="col">Status</th>
                                <th scope="col" class="text-center">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $destinations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $destination): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($loop->iteration); ?></th>
                                <td><?php echo e($destination->name); ?></td>
                                <td><?php echo e($destination->location); ?></td>
                                <td><?php echo e($destination->price); ?></td>
                                <td>
                                    <?php if($destination->type == 'a'): ?>
                                    <span>Quantity/Paket</span>
                                    <?php elseif($destination->type == 'b'): ?>
                                    <span>Quantity</span>
                                    <?php elseif($destination->type == 'c'): ?>
                                    <span class="badge bg-secondary">Coming soon</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($destination->status == 'ready'): ?>
                                    <span>Ready</span>
                                    <?php elseif($destination->status == 'not ready'): ?>
                                    <span class="badge bg-secondary">Coming soon</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <ul class="d-flex list-unstyled mb-0 justify-content-center">
                                        <li class="me-2">
                                            <a href="<?php echo e(route('admin.destination.edit', $destination->id)); ?>"><i class="link-icon"  data-feather="edit"></i></a>
                                        </li>
                                        <li><a href="#"><i class="link-icon"  data-feather="delete"></i></a></li>
                                    </ul>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->startPush('scripts'); ?>
    <script type="text/javascript">
        $(function () {

        });
      </script>
    <?php $__env->stopPush(); ?>
      <?php if (isset($component)) { $__componentOriginal0be8990d8653d19af0b3ac36178d74f2b6ec11fb = $component; } ?>
<?php $component = App\View\Components\Admin\Booking\Show::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.booking.show'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Admin\Booking\Show::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0be8990d8653d19af0b3ac36178d74f2b6ec11fb)): ?>
<?php $component = $__componentOriginal0be8990d8653d19af0b3ac36178d74f2b6ec11fb; ?>
<?php unset($__componentOriginal0be8990d8653d19af0b3ac36178d74f2b6ec11fb); ?>
<?php endif; ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2b4fb1c6c26cbcbc26d950a3971ca92bb1fca250)): ?>
<?php $component = $__componentOriginal2b4fb1c6c26cbcbc26d950a3971ca92bb1fca250; ?>
<?php unset($__componentOriginal2b4fb1c6c26cbcbc26d950a3971ca92bb1fca250); ?>
<?php endif; ?>
<?php /**PATH /home/hamdani/code/e-ticket-admin/resources/views/admin/destination/index.blade.php ENDPATH**/ ?>