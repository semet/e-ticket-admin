<section class="breadcrumb-main pb-20 pt-14" style="background-image: url(<?php echo e(asset('assets/images/bg/bg1.jpg')); ?>);">
    <div class="section-shape section-shape1 top-inherit bottom-0" style="background-image: url(<?php echo e(asset('assets/images/shape8.png')); ?>);"></div>
    <div class="breadcrumb-outer">
        <div class="container">
            <div class="breadcrumb-content text-center">
                <h1 class="mb-3"><?php echo e($title); ?></h1>
            </div>
        </div>
    </div>
    <div class="dot-overlay"></div>
</section>
<?php /**PATH /home/hamdani/code/e-ticket-admin/resources/views/components/partials/page-title.blade.php ENDPATH**/ ?>