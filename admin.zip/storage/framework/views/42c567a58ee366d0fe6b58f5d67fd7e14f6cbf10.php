<?php if (isset($component)) { $__componentOriginal7c82e5f349ef25bc970c1f6243ded321b5bb0b6f = $component; } ?>
<?php $component = App\View\Components\Layouts\Main::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.main'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Layouts\Main::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
       Profil User
     <?php $__env->endSlot(); ?>
    <section class="trending pt-6 pb-0 bg-lgrey">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div class="single-content">
                        <div id="highlight" class="mb-4">
                            <div class="single-full-title border-b mb-2 pb-2">
                                <div class="single-title">
                                    <h2 class="mb-1">Selamat Datang <?php echo e(auth()->user()->name); ?></h2>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

                <!-- sidebar starts -->
                <?php if (isset($component)) { $__componentOriginal6e0ad727b791879571aefb74df8c2828931f2d48 = $component; } ?>
<?php $component = App\View\Components\User\Sidebar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('user.sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\User\Sidebar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6e0ad727b791879571aefb74df8c2828931f2d48)): ?>
<?php $component = $__componentOriginal6e0ad727b791879571aefb74df8c2828931f2d48; ?>
<?php unset($__componentOriginal6e0ad727b791879571aefb74df8c2828931f2d48); ?>
<?php endif; ?>
            </div>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7c82e5f349ef25bc970c1f6243ded321b5bb0b6f)): ?>
<?php $component = $__componentOriginal7c82e5f349ef25bc970c1f6243ded321b5bb0b6f; ?>
<?php unset($__componentOriginal7c82e5f349ef25bc970c1f6243ded321b5bb0b6f); ?>
<?php endif; ?>
<?php /**PATH /home/hamdani/code/e-ticket/resources/views/user/profile.blade.php ENDPATH**/ ?>